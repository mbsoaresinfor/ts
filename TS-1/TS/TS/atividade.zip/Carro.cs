﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TS
{
    public class Carro
    {
        public int codigo;
        public String modelo;
        public String marca;
        public String placa;
        public int anoFabricacao;
        public String nomeProprietario;
        public double valorTotal;
        public bool eFinanciado;
        public double valorFinanciamento;
    }
}
